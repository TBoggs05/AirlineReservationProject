AIRLINE PROJECT README:

SYSTEM REQS:
-C++/G++ for compilation
-make

HOW TO RUN:
1.) In the terminal, type 'make ReservationProgram'

HOW TO COMPILE:
1.)In the terminal, type './ReservationProgram'
2.)After exiting the program, type 'make clean' to clean up object files.